import React, { Component } from 'react';
import FilterableProductTable from './FilterableProductTable';
import MessageBox from './components/MessageBox';
import './App.css';
import Products from './Products';


class App extends Component {
  render() {
    return (
      <div className="container">
      <MessageBox className="alert">Our Products</MessageBox>
      <section className="guideline-section">
        <FilterableProductTable Products={Products}/>
      </section>
      </div>
    );
  }
}

export default App;
