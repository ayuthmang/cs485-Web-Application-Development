const Products = [
  {category: 'Sporting Goods', price: '$49.99', stocked: true, name: 'Football', sku:'1234'},
  {category: 'Sporting Goods', price: '$9.99', stocked: true, name: 'Baseball', sku:'3444'},
  {category: 'Sporting Goods', price: '$29.99', stocked: false, name: 'Basketball', sku:'1344'},
  {category: 'Electronics', price: '$99.99', stocked: true, name: 'iPod Touch', sku:'3422'},
  {category: 'Electronics', price: '$399.99', stocked: false, name: 'iPhone 5', sku:'2567'},
  {category: 'Electronics', price: '$199.99', stocked: true, name: 'Nexus 7', sku:'3214'}
];

export default Products;