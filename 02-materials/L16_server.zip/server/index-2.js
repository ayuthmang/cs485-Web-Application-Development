var encrypt = require('./encryptModule');
var database = [{
  name: 'meAsUser', 
  password: '$2a$10$LiliyJwXf93YanqqKpHZQ.jkjdpWbSvlsIUhsa0bcizT5ImwDex/e',
  plaintext: 'mySecret',
}];

var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');

var app = express();
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// Authentication and Authorization Middleware
function checkAuth(req, res, next) {
  if (req.session.inSession && req.session.user) {
    next();
  }
  else {
    res.send('You are not authorized to view this page. '+
             'Please <a href="/login">logon</a>');
  }
}

var checkLogin = async function(user, pwd) {
  var dbUser = database.find(({name}) => name === user);
  if (!dbUser) return false;
//  return encrypt.compareSyncPassword(pwd, dbUser.password);
  return encrypt.comparePassword(pwd, dbUser.password);
}

var port = 4000;
 
app.post('/api/signup', (req, res) => {
  res.status(404).json({errors: {global: "Invalid credential"}});
});

app.post('/login', function (req, res, next) {
  console.log(`user: ${req.body.username} pwd: ${req.body.password}`)
  if (!req.body.username || !req.body.password) {
    res.send('login failed');    
  } else {
    checkLogin(req.body.username, req.body.password)
    .then(checked => {
      if (checked) {
        console.log(req.body.username + " logged in");
        req.session.user = req.body.username;
        req.session.inSession = true;
        res.send("login success! Click <a href='/content'>here</a> to see the authorized content.");
    }
      else {
        res.send('incorrect username or password');
      }
    });
}});

app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(port, function() { console.log(`start http server on ${port}`); });
