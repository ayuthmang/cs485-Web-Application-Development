const User = require('../models/User.js');
const bcrypt = require('bcrypt');
const validator = require('validator');
const ObjectId = require('mongodb').ObjectID;

const usrFieldProjection = { 
    __v: false,
    //_id: false,
    password: false
  };

// Create and Save a new user
exports.create = (req, res) => {
  const {name, email, password, color} = req.body;

  // omit checking for correctness before save
  // if invalid content 
  // return res.status(400).json({errors: {global: "Invalid User profile!"}});

  bcrypt.genSalt(10, (err, salt) => {
    bcrypt.hash(password, salt, (err, hash) => {
      if (err) 
        res.status(400).json({errors: {global: 'Failed to register user: ' + err}});

      var newUser = new User({
        name: name,
        email: email,
        password: hash,
        color: color
      })
      // Save User in the database
      User.init()
      .then(function() { // avoid dup by wait until finish building index
        newUser.save()
          .then(user => {
            res.json({message: 'User Registered', email: user.email});
          }).catch(err => {
            res.status(400).json({errors: {global: 'Failed to register user: '+  err.errmsg}});
          });
      });
    });
  });
};
// check logon
/*
exports.checkLogon = (req, res) => {
  const {email, password} = req.body;
  if (!email || !password) {
    res.status(404).json({errors: {global: "Invalid credential"}});
  } 

  User.findOne({email: email}, (err, user) => {
    if (err || !user) {
      res.status(400).json({errors: {global: err.message||"Invalid email"}});
    }
    else {
      bcrypt.compare(password, user.password)
      .then(matched => {
        if (matched) {
          res.json({ "user": {
            id: user._id,
            name: user.name,
            email: user.email,
            color: user.color
          }});
        }
        else res.status(404).json({errors: {global: "Invalid credential"}});
      })
      .catch(err => res.status(404).json({errors: {global: "Invalid credential!"}}));
    }
  });
}
*/

const jwt = require('jsonwebtoken');
const config = require("../config/jwtConfig");

exports.checkLogon = (req, res) => {
  const {email, password} = req.body;
  if (!email || !password) {
    res.status(404).json({errors: {global: "Invalid credential"}});
  } 

  User.findOne({email: email}, (err, user) => {
    if (err || !user) {
      res.status(400).json({errors: {global: err||"Invalid email"}});
    }
    else {
      bcrypt.compare(password, user.password)
      .then(matched => {
        if (matched) {
          const token = jwt.sign({ email: user.email, name: user.name }, 
                                 config.jwtSecret,
                                 { expiresIn: 3600 }); // 1 hour

          res.json({ user: {
              id: user._id,
              name: user.name,
              email: user.email,
              color: user.color,
            },
            success: true,
            token: "JWT " + token,
          });
        }
        else res.status(404).json({errors: {global: "Invalid credential"}});
      })
      .catch(err => res.status(404).json({errors: {global: "Invalid credential!"}}));
    }
  });
}

// Retrieve and return all Users from the database.
exports.list = (req, res) => {
  var usersProjection = { 
    __v: false,
    //_id: false,
    password: false
  };
  User.find({}, usersProjection) 
//  User.find({isDeleted:false}, usersProjection)  // show only not mark as deleted
  .then(users => {
    res.json(users);
  }).catch(err => {
    res.status(500).send({
        errors: {global: err.message || "Some error occurred while retrieving Users."
    }});
  });
};

// Find a single User with an email
exports.findByEmail = (req, res) => {
  const email = req.params.email;
  User.findOne({email: email}, usrFieldProjection)
 .then(user => {
    if(!user) {
      return res.status(404).send({
          errors: {global: "User not found with email " + req.params.email
      }});            
    }
    res.json(user);
  }).catch(err => {
    return res.status(500).send({
      errors: {global: "Error retrieving User with email " + req.params.email
    }});
  });
};

// Find a single User with a userId
exports.get = (req, res) => {
  const id =  req.params.userId;
  User.findById(id, usrFieldProjection)
 .then(user => {
    if(!user) {
      return res.status(404).send({
          errors: {global: "User not found with id " + req.params.userId
      }});            
    }
    res.json(user);
  }).catch(err => {
    if(err.kind === 'ObjectId') {
      return res.status(404).send({
          errors: {global: "User not found with id " + req.params.userId
      }});                
    }
    return res.status(500).send({
      errors: {global: "Error retrieving User with id " + req.params.userId
    }});
  });
};

// Update a User identified by the userId in the request
exports.put = (req, res) => {
  // Validate Request
  const data = req.body || {};

  if (data.email && !validator.isEmail(data.email)) {
    return res.status(422).json({errors: {global: 'Invalid email address.'}});
  }

  if (data.name && !validator.isAlphanumeric(data.name)) {
    return res.status(422).send('name must be alphanumeric.');
  }

  // Find User and update it with the request body
  User.findByIdAndUpdate(req.params.userId,{$set:req.body}, {new: true})
  .then(user => {
    if(!user) {
      return res.status(404).send({
             errors: {global: "User not found with id " + req.params.userId
      }});
    }
    res.send(user);
  }).catch(err => {
    if(err.kind === 'ObjectId') {
      return res.status(404).send({
             errors: {global: "User not found with id " + req.params.userId
      }});                
    }
    return res.status(500).send({
            errors: {global: "Error updating User with id " + req.params.userId
    }});
  });
};

exports.delete = (req, res) => {
  User.findByIdAndUpdate(
    { _id: req.params.userId },
    { $set: { isDeleted: true }}
  )
    .then(user => {
      if (!user) {
        res.status(404).send({
           errors: {global: "User not found with id " + req.params.userId
          }});
      }
      res.send({message: "Successfully marked user as deleted!"});
    })
    .catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                errors: {global: "User not found with id " + req.params.userId
            }});                
        }
        return res.status(500).send({
            errors: {global: "Could not delete User with id " + req.params.userId
        }});
    });
};

// Delete a User with the specified userId in the request
exports.deletePermanent = (req, res) => {
    User.findByIdAndRemove(req.params.userId)
    .then(user => {
        if(!user) {
            return res.status(404).send({
                errors: {global: "User not found with id " + req.params.userId
            }});
        }
        res.send({message: "User deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                errors: {global: "User not found with id " + req.params.userId
            }});                
        }
        return res.status(500).send({
            errors: {global: "Could not delete User with id " + req.params.userId
        }});
    });
};

exports.validateToken = (req, res) => {
  const token = req.headers['authorization'].substring(4);
  try {
    var decode = jwt.verify(token, config.jwtSecret);
    res.json(decode);
  }
  catch (err) {
    res.status(401).json({err});
  }
};
