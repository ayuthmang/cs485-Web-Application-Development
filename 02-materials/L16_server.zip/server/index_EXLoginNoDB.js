var encrypt = require('./encryptModule');
var database = [{
  email: 'yao@cs.com', 
  password: '$2a$10$LiliyJwXf93YanqqKpHZQ.jkjdpWbSvlsIUhsa0bcizT5ImwDex/e',
  plaintext: 'mySecret',
}];

var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');

var app = express();
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

var port = 4000;

var checkLogin = async function(user, pwd) {
  var dbUser = database.find(({email}) => email === user);
  if (!dbUser) return false;
//  return encrypt.compareSyncPassword(pwd, dbUser.password);
  return encrypt.comparePassword(pwd, dbUser.password);
}
 
app.post('/api/signup', (req, res) => {
  const {email, password} = req.body;
  if (!email || !password) {
    res.status(404).json({errors: {global: "Invalid credential"}});
  } else {
    checkLogin(email, password)
    .then(checked => {
      if (checked) {
        console.log(email + " logged in");
        res.status(200).json({user: {email: email}});
      }
      else {
        res.status(404).json({errors: {global: "Invalid credential"}});
      }
    });
}});

app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(port, function() { console.log(`start http server on ${port}`); });
