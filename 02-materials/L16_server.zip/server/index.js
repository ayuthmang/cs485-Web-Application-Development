var express = require('express');
var path = require('path');

var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

const mongoose = require("mongoose");
const config = require('./config/database');

mongoose.connect(config.database);
mongoose.connection.on('connected', () => {
  console.log('Connected to database '+config.database);
});
mongoose.connection.on('error', () => {
  console.log('Database error');
});

var users = require('./routes/userRouter');

// REST for users
app.use('/api', users);


app.get('/', (req, res) => {
  res.send('Invalid Endport');
});

app.get('*', (req, res) => {
  res.sendfile(path.join(__dirname, 'public/index.html'));
})

var port = 4000;

app.listen(port, function() { console.log(`start http server on ${port}`); });
