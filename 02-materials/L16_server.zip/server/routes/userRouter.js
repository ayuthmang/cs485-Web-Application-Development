// look for more detail at
// https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs/routes
var express = require('express');
var router = express.Router();
var User_Ctrl = require('../controllers/userController');

var auth = require("../utils/jwt-passport.js")();  
router.use(auth.initialize());

router.post('/signin', User_Ctrl.checkLogon);
router.post('/validateToken', User_Ctrl.validateToken);
router.post('/user', User_Ctrl.create);
router.get('/users', User_Ctrl.list);
router.get('/user/email/:email', User_Ctrl.findByEmail);
router.get('/user/:userId', auth.authenticate(), User_Ctrl.get);
router.put('/user/:userId', auth.authenticate(), User_Ctrl.put);
router.delete('/user/delete/:userId', auth.authenticate(), User_Ctrl.deletePermanent);
router.delete('/user/:userId', auth.authenticate(), User_Ctrl.delete);

module.exports = router;