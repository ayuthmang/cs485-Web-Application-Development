module.exports = {  
  jwtSecret: 'yoursecret', 
  jwtSession: {
      session: false
  }
};