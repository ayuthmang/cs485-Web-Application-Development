module.exports =  {
  // do not forget to create user and grant role to this user
  database: 'mongodb://localhost:27017/products',
  userMongoClient: true,
}