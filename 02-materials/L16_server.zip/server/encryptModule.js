var bcrypt = require('bcrypt');

var encrypt = {
  encryptPwd: function(password, callback) {
    bcrypt.genSalt(10, function(err, salt) {
      if (err) return callback(err);
      bcrypt.hash(password, salt, function(err, hash) {
        return callback(err, hash);
      });
  })},
  
  comparePassword: async function(password, encPwd) { 
      return await bcrypt.compare(password, encPwd);
  },
  compareSyncPassword: function(password, encPwd) { 
      return bcrypt.compareSync(password, encPwd);
  },
}

/*
let password = "mySecret";
encrypt.encryptPwd(password, (e, hash) => { 
  console.log(hash);
  encrypt.comparePassword(password, hash, (e, res) => console.log("result ", res));
});
console.log("done")
*/
module.exports = encrypt;
