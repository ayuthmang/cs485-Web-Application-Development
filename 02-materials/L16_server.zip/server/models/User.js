const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const UserSchema = new mongoose.Schema({
  name: { type: String, trim: true, required: [true, 'Name is required']},
  email: { type: String, trim: true, unique: true, required: true},
  password: {type: String, required: true },
  color: {type: String},
  isDeleted: {type: Boolean, default: false },
  signUpDate: {type: Date, default: Date.now()}
});

const User = module.exports = mongoose.model('User', UserSchema, 'User');

// check more on validation at http://mongoosejs.com/docs/validation.html